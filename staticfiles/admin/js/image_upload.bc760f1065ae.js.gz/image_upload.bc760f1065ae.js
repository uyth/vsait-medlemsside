window.addEventListener("load", function () {
  (function ($) {
    console.log("image_upload.js loaded");

    // const file_upload = $(".file-upload").get(0).children[0];
    // console.log("/static/media/"+file_upload.href.split("/media/")[1])
    // file_upload.href = "/static/media/"+file_upload.href.split("/media/")[1];
  })(django.jQuery);
});
